require('./bootstrap');
window.axios.defaults.withCredentials = true;
